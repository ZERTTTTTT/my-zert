<?php
session_start();
if (!isset($_SESSION['login'])) {
  header("Location: login.php");
  exit;
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Admin NEV JAV</title>
  <link rel="stylesheet" href="assets/style.css">
</head>
<body>
  <header>
    <h1>Panel Admin - NEV JAV</h1>
    <nav>
      <a href="index.php">Home</a>
      <a href="logout.php">Logout</a>
    </nav>
  </header>

  <h2>Upload Video Baru</h2>
  <form action="upload.php" method="post" enctype="multipart/form-data">
    <input type="file" name="video" accept="video/*" required>
    <button type="submit">Upload</button>
  </form>
</body>
</html>
