<?php
$videos = array_filter(scandir("videos"), fn($f) => preg_match('/\.(mp4|webm)$/', $f));
?>

<!DOCTYPE html>
<html>
<head>
  <title>NEV JAV - Streaming Video</title>
  <link rel="stylesheet" href="assets/style.css">
</head>
<body>
  <header>
    <h1>NEV JAV</h1>
    <nav>
      <a href="index.php">Home</a>
      <a href="admin.php">Admin</a>
    </nav>
  </header>

  <section>
    <h2>Daftar Video</h2>
    <ul>
      <?php foreach ($videos as $v): ?>
        <li><a href="?v=<?= urlencode($v) ?>"><?= htmlspecialchars(pathinfo($v, PATHINFO_FILENAME)) ?></a></li>
      <?php endforeach; ?>
    </ul>

    <?php if (isset($_GET['v']) && file_exists("videos/" . $_GET['v'])): ?>
      <video controls autoplay>
        <source src="videos/<?= htmlspecialchars($_GET['v']) ?>" type="video/mp4">
        Video tidak bisa diputar.
      </video>
    <?php endif; ?>
  </section>
</body>
</html>
