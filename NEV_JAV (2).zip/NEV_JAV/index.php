<?php
$videos = array_filter(scandir("videos"), fn($f) => preg_match('/\.(mp4|webm)$/', $f));
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>NEV JAV - Streaming Video</title>
  <link rel="stylesheet" href="assets/style.css">
  <style>
    .video-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
      gap: 20px;
    }
    .video-card {
      background-color: #1a1a1a;
      padding: 15px;
      border-radius: 12px;
      text-align: center;
      box-shadow: 0 0 10px rgba(0,255,255,0.2);
    }
    .video-card a {
      color: #00ffff;
      text-decoration: none;
      font-weight: bold;
    }
    .video-card a:hover {
      text-decoration: underline;
    }
    .video-card video {
      width: 100%;
      border-radius: 8px;
      margin-top: 10px;
    }
  </style>
</head>
<body>
  <header>
    <h1>🎬 NEV JAV</h1>
    <nav>
      <a href="index.php">🏠 Beranda</a>
      <a href="admin.php">🔐 Admin</a>
    </nav>
  </header>

  <section>
    <h2>📺 Daftar Video</h2>
    <div class="video-grid">
      <?php foreach ($videos as $v): ?>
        <div class="video-card">
          <a href="?v=<?= urlencode($v) ?>">
            <?= htmlspecialchars(pathinfo($v, PATHINFO_FILENAME)) ?>
          </a>
          <video muted>
            <source src="videos/<?= htmlspecialchars($v) ?>" type="video/mp4">
          </video>
        </div>
      <?php endforeach; ?>
    </div>

    <?php if (isset($_GET['v']) && file_exists("videos/" . $_GET['v'])): ?>
      <h2>▶️ Sekarang Menonton: <?= htmlspecialchars($_GET['v']) ?></h2>
      <video controls autoplay style="width:100%; max-width:800px; margin-top:20px;">
        <source src="videos/<?= htmlspecialchars($_GET['v']) ?>" type="video/mp4">
        Browser kamu tidak mendukung video.
      </video>
    <?php endif; ?>
  </section>
</body>
</html>
