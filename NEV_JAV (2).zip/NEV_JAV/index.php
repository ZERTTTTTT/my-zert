<?php
$videos = array_filter(scandir("videos"), fn($f) => preg_match('/\.(mp4|webm)$/', $f));
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>NEV JAV - Video Streaming</title>
  <link rel="stylesheet" href="assets/style.css">
  <style>
    body {
      background-color: #0b0b0b;
      color: #f0f0f0;
      font-family: 'Segoe UI', sans-serif;
      margin: 0;
      padding: 0;
    }
    header {
      background-color: #1a1a1a;
      padding: 20px;
      text-align: center;
      box-shadow: 0 0 10px #00ffff44;
    }
    header h1 {
      color: #00ffff;
      margin: 0;
      font-size: 2em;
    }
    nav {
      margin-top: 10px;
    }
    nav a {
      color: #00ffee;
      text-decoration: none;
      margin: 0 10px;
      font-weight: bold;
    }
    nav a:hover {
      text-decoration: underline;
    }
    .content {
      padding: 20px;
    }
    .video-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(160px, 1fr));
      gap: 16px;
    }
    .video-card {
      background-color: #1a1a1a;
      padding: 10px;
      border-radius: 12px;
      overflow: hidden;
      box-shadow: 0 0 8px rgba(0,255,255,0.15);
      transition: transform 0.2s ease;
    }
    .video-card:hover {
      transform: scale(1.03);
    }
    .video-card video {
      width: 100%;
      border-radius: 10px;
    }
    .video-title {
      color: #0ff;
      text-align: center;
      font-size: 0.9em;
      margin-top: 8px;
    }
    .player {
      margin-top: 30px;
      text-align: center;
    }
    .player video {
      width: 100%;
      max-width: 800px;
      border-radius: 12px;
    }
  </style>
</head>
<body>
  <header>
    <h1>NEV JAV</h1>
    <nav>
      <a href="index.php">🏠 Home</a>
      <a href="admin.php">🔐 Admin</a>
    </nav>
  </header>

  <div class="content">
    <h2>🔥 Video Terbaru</h2>
    <div class="video-grid">
      <?php foreach ($videos as $v): ?>
        <div class="video-card">
          <a href="?v=<?= urlencode($v) ?>">
            <video muted loop preload="metadata" poster="">
              <source src="videos/<?= htmlspecialchars($v) ?>" type="video/mp4">
            </video>
            <div class="video-title"><?= htmlspecialchars(pathinfo($v, PATHINFO_FILENAME)) ?></div>
          </a>
        </div>
      <?php endforeach; ?>
    </div>

    <?php if (isset($_GET['v']) && file_exists("videos/" . $_GET['v'])): ?>
      <div class="player">
        <h2>▶️ Sedang Diputar</h2>
        <video controls autoplay>
          <source src="videos/<?= htmlspecialchars($_GET['v']) ?>" type="video/mp4">
        </video>
        <p><?= htmlspecialchars($_GET['v']) ?></p>
      </div>
    <?php endif; ?>
  </div>
</body>
</html>
