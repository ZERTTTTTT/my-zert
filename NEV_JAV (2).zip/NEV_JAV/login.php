<?php
session_start();
$users = json_decode(file_get_contents("data/users.json"), true);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $user = $_POST['username'];
  $pass = $_POST['password'];
  if (isset($users[$user]) && $users[$user] === $pass) {
    $_SESSION['login'] = true;
    header("Location: admin.php");
  } else {
    $error = "Login gagal!";
  }
}
?>

<!DOCTYPE html>
<html>
<head><title>Login Admin</title></head>
<body>
  <h2>Login Admin NEV JAV</h2>
  <form method="post">
    <input type="text" name="username" placeholder="User" required><br>
    <input type="password" name="password" placeholder="Pass" required><br>
    <button>Login</button>
  </form>
  <?php if (isset($error)) echo "<p>$error</p>"; ?>
</body>
</html>
