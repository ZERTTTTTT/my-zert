<?php
session_start();
if (!isset($_SESSION['login'])) die("Unauthorized");

if (isset($_FILES['video'])) {
  $target = "videos/" . basename($_FILES['video']['name']);
  move_uploaded_file($_FILES['video']['tmp_name'], $target);
  header("Location: admin.php");
}
